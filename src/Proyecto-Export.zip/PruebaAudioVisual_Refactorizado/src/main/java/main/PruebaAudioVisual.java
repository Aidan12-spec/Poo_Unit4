package main;

import controller.ControladorContenido;

public class PruebaAudioVisual {
    public static void main(String[] args) {
        ControladorContenido controlador = new ControladorContenido();
        controlador.iniciar();
    }
}
