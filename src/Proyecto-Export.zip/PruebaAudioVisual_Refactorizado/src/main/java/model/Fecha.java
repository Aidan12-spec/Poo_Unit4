package model;

public class Fecha {
    private String dia;

    public Fecha(String dia) { this.dia = dia; }
    public String getDia() { return dia; }
    public void setDia(String dia) { this.dia = dia; }
}